import javax.swing.JOptionPane;

public class MemberDTO {
	
	private	String	mem_Email;
	JOptionPane input;

	GawiGame game;
	
	public	MemberDTO() {
		inputEmail();
	}
	
	//메서드 리턴을 void로 했는데, 예시 끝난 후 로직상 변경해야 할 겁니다.
	public void inputEmail() {
		this.mem_Email = input.showInputDialog("Email을 입력 바랍니다.");
		game = new GawiGame();
	}
	
	
	public String getMem_Email() {
		return mem_Email;
	}
}
