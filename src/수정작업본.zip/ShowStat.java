
public class ShowStat {
	
	
	GawiGame game;
	
	public ShowStat() {
		game = new GawiGame();
	}
	
	void showStatMethod(){
		game.getLoss();
		game.getWin();
		game.getPlayCount();
	}

}
